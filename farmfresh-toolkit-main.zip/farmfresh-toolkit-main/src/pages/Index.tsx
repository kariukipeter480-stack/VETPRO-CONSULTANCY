import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ChevronRight, ShoppingCart, PhoneCall, Search, Truck, ShieldCheck, BadgeCheck } from "lucide-react";
import { motion } from "framer-motion";

// Import generated images
import heroFarming from "@/assets/hero-farming.jpg";
import poultryEquipment from "@/assets/poultry-equipment.jpg";
import dairyEquipment from "@/assets/dairy-equipment.jpg";
import pigEquipment from "@/assets/pig-equipment.jpg";
import sheepGoats from "@/assets/sheep-goats.jpg";
import rabbitEquipment from "@/assets/rabbit-equipment.jpg";
import petSupplies from "@/assets/pet-supplies.jpg";
import gardenEquipment from "@/assets/garden-equipment.jpg";
import dealsBanner from "@/assets/deals-banner.jpg";

const categories = [
  { key: "poultry", name: "Poultry", desc: "Drinkers, feeders, brooders, cages", img: poultryEquipment },
  { key: "dairy", name: "Dairy", desc: "Milking equipment, hygiene, feeds", img: dairyEquipment },
  { key: "pig", name: "Pig", desc: "Feeders, farrowing crates, health", img: pigEquipment },
  { key: "sheep-goats", name: "Sheep & Goats", desc: "Drenches, tagging, handling", img: sheepGoats },
  { key: "rabbits", name: "Rabbits", desc: "Cages, drinkers, vitamins", img: rabbitEquipment },
  { key: "pets", name: "Pets", desc: "Dog & cat food, grooming, meds", img: petSupplies },
  { key: "gardening", name: "Gardening", desc: "Drip kits, tools, sprayers", img: gardenEquipment },
  { key: "deals", name: "Deals", desc: "Weekly offers & bundles", img: dealsBanner },
];

const featured = [
  { id: 1, name: "Automatic Poultry Nipple Line 60m", price: 28500, badge: "Bestseller" },
  { id: 2, name: "Electric Knapsack Sprayer 16L (12V/8Ah)", price: 6500, badge: "Hot" },
  { id: 3, name: "Milking Machine – 1 Cow Portable", price: 115000, badge: "New" },
  { id: 4, name: "Piglet Creep Feeder (Stainless)", price: 9500, badge: "Limited" },
];

const perks = [
  { icon: <Truck className="h-5 w-5" />, title: "Same‑day Nairobi", text: "Order by 2pm. Next‑day upcountry." },
  { icon: <ShieldCheck className="h-5 w-5" />, title: "Genuine & Warrantied", text: "Authorized brands, easy returns." },
  { icon: <BadgeCheck className="h-5 w-5" />, title: "M‑Pesa, Cards, Bank", text: "Secure checkout with receipts." },
];

function KES(n: number) { 
  return new Intl.NumberFormat("en-KE", { 
    style: "currency", 
    currency: "KES", 
    maximumFractionDigits: 0 
  }).format(n); 
}

const Index = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Top bar */}
      <div className="w-full bg-emerald-700 text-white">
        <div className="mx-auto max-w-7xl px-4 py-2 flex items-center justify-between text-sm">
          <div>Based in Nairobi • Open Mon–Sat 8am–6pm</div>
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1">
              <PhoneCall className="h-4 w-4"/> +254 7XX XXX XXX
            </span>
            <Button size="sm" variant="secondary" className="bg-white text-emerald-800 hover:bg-emerald-50">
              WhatsApp
            </Button>
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="mx-auto max-w-7xl px-4 py-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex items-center gap-2">
          <div className="h-10 w-10 rounded-2xl bg-primary"></div>
          <div className="font-bold text-xl">AgriHub Nairobi</div>
        </div>
        <div className="flex-1 md:max-w-xl">
          <div className="relative">
            <Input 
              placeholder="Search products e.g. 'nipple drinker', 'drip kit 1 acre'" 
              className="pl-10 rounded-xl border-input focus:ring-primary" 
            />
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          </div>
        </div>
        <Button className="inline-flex items-center gap-2 rounded-xl">
          <ShoppingCart className="h-4 w-4"/>Cart
        </Button>
      </header>

      {/* Hero */}
      <section className="mx-auto max-w-7xl px-4">
        <motion.div 
          initial={{ opacity: 0, y: 10 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 0.5 }}
          className="rounded-3xl bg-gradient-to-r from-emerald-700 via-primary to-accent text-white p-8 md:p-12 shadow-lg"
          style={{ boxShadow: 'var(--shadow-medium)' }}
        >
          <div className="grid md:grid-cols-2 gap-6 items-center">
            <div>
              <h1 className="text-3xl md:text-5xl font-extrabold leading-tight">
                Livestock & Gardening Equipment for East African Farms
              </h1>
              <p className="mt-3 text-emerald-100">
                Poultry • Dairy • Pig • Sheep & Goats • Pets • Rabbits • Gardening. 
                Fast delivery from Nairobi, fair prices, trusted brands.
              </p>
              <div className="mt-5 flex flex-wrap gap-3">
                <Button size="lg" variant="secondary" className="rounded-xl">
                  Shop New Arrivals
                </Button>
                <Button size="lg" className="bg-black hover:bg-black/80 rounded-xl">
                  See Weekly Deals
                </Button>
              </div>
            </div>
            <div className="aspect-video rounded-2xl overflow-hidden shadow-inner">
              <img 
                src={heroFarming} 
                alt="Modern farming equipment on East African farm"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </motion.div>
      </section>

      {/* Perks */}
      <section className="mx-auto max-w-7xl px-4 mt-8 grid md:grid-cols-3 gap-4">
        {perks.map((p, i) => (
          <Card key={i} className="rounded-2xl" style={{ boxShadow: 'var(--shadow-soft)' }}>
            <CardHeader className="flex-row items-center gap-3">
              <div className="text-primary">{p.icon}</div>
              <CardTitle className="text-lg">{p.title}</CardTitle>
            </CardHeader>
            <CardContent className="pt-0 text-sm text-muted-foreground">{p.text}</CardContent>
          </Card>
        ))}
      </section>

      {/* Categories */}
      <section className="mx-auto max-w-7xl px-4 mt-10">
        <div className="flex items-end justify-between">
          <h2 className="text-2xl font-bold">Shop by Category</h2>
          <Button variant="ghost" className="inline-flex items-center rounded-xl">
            View all<ChevronRight className="h-4 w-4"/>
          </Button>
        </div>
        <div className="mt-4 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {categories.map((c) => (
            <motion.a 
              whileHover={{ y: -2 }} 
              key={c.key} 
              href={`/#/category/${c.key}`} 
              className="block rounded-2xl overflow-hidden shadow group transition-all duration-300 hover:shadow-lg"
            >
              <div 
                className="h-40 bg-muted bg-cover bg-center" 
                style={{ backgroundImage: `url(${c.img})` }} 
              />
              <div className="p-4">
                <div className="font-semibold group-hover:text-primary transition-colors">
                  {c.name}
                </div>
                <div className="text-sm text-muted-foreground">{c.desc}</div>
              </div>
            </motion.a>
          ))}
        </div>
      </section>

      {/* Featured products */}
      <section className="mx-auto max-w-7xl px-4 mt-10">
        <div className="flex items-end justify-between">
          <h2 className="text-2xl font-bold">Featured Products</h2>
          <Button variant="ghost" className="inline-flex items-center rounded-xl">
            Browse catalog<ChevronRight className="h-4 w-4"/>
          </Button>
        </div>
        <div className="mt-4 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {featured.map((p) => (
            <Card key={p.id} className="rounded-2xl" style={{ boxShadow: 'var(--shadow-soft)' }}>
              <div className="h-44 bg-muted rounded-t-2xl" />
              <CardHeader className="pb-0">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base leading-snug">{p.name}</CardTitle>
                  <span className="text-xs bg-primary text-primary-foreground px-2 py-0.5 rounded-full">
                    {p.badge}
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="font-bold">{KES(p.price)}</div>
                  <Button size="sm" className="rounded-xl">Add to cart</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA strip */}
      <section className="mx-auto max-w-7xl px-4 mt-12">
        <div className="rounded-2xl border p-6 flex flex-col md:flex-row items-center justify-between gap-4" 
             style={{ boxShadow: 'var(--shadow-soft)' }}>
          <div>
            <div className="text-lg font-semibold">Bulk orders & B2B pricing</div>
            <div className="text-muted-foreground text-sm">
              Supply shops, cooperatives & farms nationwide. Invoices with PIN & ETR available.
            </div>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" className="rounded-xl">Request a quote</Button>
            <Button className="rounded-xl">Talk to sales</Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-16 bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 py-10 grid md:grid-cols-4 gap-8 text-sm">
          <div>
            <div className="font-bold text-lg">AgriHub Nairobi</div>
            <p className="text-muted-foreground mt-2">
              Reliable equipment for poultry, dairy, pig, small ruminants, rabbits, pets & gardens.
            </p>
            <div className="mt-3 text-foreground">Kijabe St, CBD, Nairobi</div>
          </div>
          <div>
            <div className="font-semibold mb-2">Customer care</div>
            <ul className="space-y-1 text-muted-foreground">
              <li><a href="#" className="hover:text-primary transition-colors">Help & FAQs</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Shipping & returns</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Warranty</a></li>
            </ul>
          </div>
          <div>
            <div className="font-semibold mb-2">Shop</div>
            <ul className="space-y-1 text-muted-foreground">
              <li><a href="#" className="hover:text-primary transition-colors">All products</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">New arrivals</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Deals</a></li>
            </ul>
          </div>
          <div>
            <div className="font-semibold mb-2">Payments</div>
            <div className="flex flex-wrap gap-2">
              <span className="px-2 py-1 rounded bg-card border text-xs">M‑Pesa</span>
              <span className="px-2 py-1 rounded bg-card border text-xs">Visa</span>
              <span className="px-2 py-1 rounded bg-card border text-xs">Mastercard</span>
              <span className="px-2 py-1 rounded bg-card border text-xs">Bank</span>
            </div>
          </div>
        </div>
        <div className="border-t">
          <div className="mx-auto max-w-7xl px-4 py-4 flex items-center justify-between text-xs text-muted-foreground">
            <div>© {new Date().getFullYear()} AgriHub Nairobi. All rights reserved.</div>
            <div className="flex gap-3">
              <a href="#" className="hover:text-primary transition-colors">Privacy</a>
              <a href="#" className="hover:text-primary transition-colors">Terms</a>
              <a href="#" className="hover:text-primary transition-colors">Returns</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;